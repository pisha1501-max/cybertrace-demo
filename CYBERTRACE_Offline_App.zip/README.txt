CYBERTRACE OFFLINE DEMO — QUICK START

Files:
- index.html: the complete dashboard
- manifest.json: installable web-app settings
- sw.js: offline cache service worker

Important:
A service worker only works when served from HTTPS (or localhost). Opening index.html directly from a file manager will show the dashboard, but the service worker/offline installation may not work. You must first host these files on an HTTPS static host, then open the hosted URL online once and install/add it to the home screen. After the files have cached successfully, test airplane mode.

The app uses localStorage for demo edits. It is a fictional educational demo and does not connect to banks or inspect real accounts. Browser storage can be cleared by the browser, so keep the ZIP as a backup.

To test:
1. Upload all three files to an HTTPS static host preserving the file names.
2. Open the HTTPS site online and wait for it to load.
3. Refresh once, then use Add to Home Screen / Install if offered.
4. Turn on Airplane mode (make sure Wi-Fi is off), then reopen the installed app.
5. Test all seven sections.
